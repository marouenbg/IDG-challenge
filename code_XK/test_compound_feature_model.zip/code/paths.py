import os
path_parent = "/share/taglab/XK/IDG"
path_data = os.path.join(path_parent,"data")
path_out_data = os.path.join(path_parent,"out_data")
