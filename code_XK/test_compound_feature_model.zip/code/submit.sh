#!/bin/bash
rm ./output/*
for i in `seq 0 12`
do
   for j in `seq 0 2`
     do
       sed -i "s/main.py.*/main.py $i $j/g" one_job.sh
       sbatch one_job.sh
   done
done
        
