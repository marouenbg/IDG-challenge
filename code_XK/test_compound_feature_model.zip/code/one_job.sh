#!/bin/bash
#SBATCH --partition=production
#SBATCH --job-name=sanity
#SBATCH --nodes=1
#SBATCH -c 8
#SBATCH --ntasks=1 
#SBATCH --mem=20000 
#SBATCH --time=0-20:55:00
#SBATCH --output=./output/%j.out 
#SBATCH --error=./output/%j.err
srun /share/taglab/XK/anaconda/bin/python ./main.py 12 2
